# MANIFEST — CQS-MENUS-D04-REFERENCE
Package version: D04-R1 · v1.1 · 2026-09-28
Status: Candidate final reference — pending DevPM acceptance and repository storage.

| File | Purpose | Required to render | SHA-256 |
| --- | --- | --- | --- |
| CQS-MENUS-D04.dc.html | Package document (frames, notes, tensions, ledger) | yes | f8153094b7a5ea4f55f44638c14a4c824f91eea5a6a80db2de1a5ab211bb35c1 |
| D04-Console.dc.html | Clickable prototype; imported by the package document | yes | e4783bae48a7517da470d654ca3c778fe8ce69432f0b9704f878904609b9f780 |
| d04-data.js | Sample content + readiness model used by the prototype | yes | 3302d1411a78bb862c0fa667669070d667d6f1775a6daed80736f9374f41f711 |
| support.js | Design Component runtime | yes | 8fe7df74405f3c55f49b7249c74ea1397e65d07dea2b1bd3b4a489bec2e28cbe |
| README.md | Identity, authority, scope, provenance, open items | no | e1b3a21f27140c781fa529b2c5880b6b6e6d6b77517a5ea66421cd068322f9a1 |
| MANIFEST.md | This file | no | — |

Checksums are over the UTF-8 bytes of each file as packaged. This manifest describes the package only; it makes no claim about the CQS repository.
