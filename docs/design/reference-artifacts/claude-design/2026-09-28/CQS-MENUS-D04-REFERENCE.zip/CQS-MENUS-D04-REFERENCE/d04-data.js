// CQS MENUS D04 — shared sample content + readiness model (design evidence only; not production code)
export const GAMES = [
  { id: 'plate', title: 'Plate Tectonics Review', format: 'Board + Final', teams: 4, meta: 'Played Thu · 4 teams · Board + Final', kind: 'game' },
  { id: 'mineral', title: 'Mineral Identification Lab Review', format: 'Board + Final', teams: 4, meta: 'Played 2 weeks ago · 4 teams · Board + Final', kind: 'game' },
  { id: 'systems', title: 'Earth Systems Unit 1 Review', format: 'Classic', teams: 8, meta: 'Played Aug 28 · 8 teams · Classic', kind: 'game' },
  { id: 'moon', title: 'Moon Phases Review', format: 'Board', teams: 0, meta: 'Imported Sep 20 · no teams yet · Board', kind: 'game' },
  { id: 'weather', title: 'Weathering & Erosion Review', format: 'Board + Final', teams: 4, meta: 'Draft · 18 of 30 clues written', kind: 'draft' },
];
export const RECOVERY = { gameId: 'plate', title: 'Plate Tectonics Review', detail: 'Period 3 · interrupted 12 min ago · Round 1 · 11 of 30 clues used' };
export const ACCENTS = ['#ff7a7a', '#5cb8ff', '#5ee2a0', '#ffc75c', '#c39bff', '#4fd8d8', '#ff92c2', '#b9c9d8'];
export const BANK = [
  ['Subduction Squad', 'Pangaea Pals', 'Seismic Waves', 'Core Samples'],
  ['Magma Chamber', 'Continental Drifters', 'Hot Spots', 'Lithosphere Legends'],
  ['Fault Line Five', 'Mantle Plumes', 'Tectonic Titans', 'Rift Valley'],
  ['Ring of Fire', 'Aftershocks', 'Mid-Ocean Ridge', 'Trench Team'],
  ['Convergent Crew', 'Epicenter', 'Basalt Brigade', 'Wegener’s Wonders'],
  ['Divergent Dynamos', 'Richter Rockets', 'Asthenosphere', 'Transform Titans'],
  ['Crustal Crew', 'Tsunami Tigers', 'Pillow Lava', 'Ridge Riders'],
  ['Outer Core', 'Slab Pull', 'Volcanic Arc', 'Deep Trench'],
];
export const FULL_NAMES = { 0: 'Subduction Squad', 1: 'Magma Chamber', 2: 'Fault Line Five', 3: 'Ring of Fire' };
export const PARTIAL_NAMES = { 0: 'Subduction Squad', 1: 'Magma Chamber' };
export const EIGHT_NAMES = { 0: 'Subduction Squad', 1: 'Magma Chamber', 2: 'Fault Line Five', 3: 'Ring of Fire', 4: 'Convergent Crew', 6: 'Crustal Crew' };
export const SONY_COLORS = ['Blue', 'Orange', 'Green', 'Yellow'];
export const CATEGORIES = ['Plate Boundaries', 'Seafloor Spreading', 'Earthquakes', 'Volcanoes', 'Evidence for Drift', 'Hot Spots'];
export const VALUES = [100, 200, 300, 400, 500];
export const OPEN_CLUE = { cat: 'Plate Boundaries', value: 300, text: 'This type of boundary forms where two plates move toward each other and one sinks beneath the other.', answer: 'What is a convergent boundary (subduction zone)?' };
export const MORE_ITEMS = [
  { group: 'This clue', items: ['Skip this clue', 'Reopen a used clue', 'Adjust a score by hand'] },
  { group: 'Buzzers & keys', items: ['Buzzer repair (pairing steps)', 'Keyboard key map'] },
  { group: 'This window', items: ['High-contrast theme', 'Reduce motion'] },
  { group: 'This class', items: ['Export class summary', 'End class early'] },
];

export const INITIAL = { screen: 'home', gameId: 'plate', names: {}, active: 'names', buzzSkipped: false, displayOpen: false, soundTested: false, muted: false, moreOpen: false, sony: 'ready' };
export function gameById(id) { return GAMES.find((g) => g.id === id) || GAMES[0]; }

// Static frames for the package doc. Each is a full state; 'live' = interactive.
export function effective(props, state) {
  const f = props.frame; if (!f || f === 'live') return state;
  const b = { ...INITIAL };
  switch (f) {
    case 'home': return { ...b, screen: 'home' };
    case 'home-norecovery': return { ...b, screen: 'home', recovery: false };
    case 'home-empty': return { ...b, screen: 'home', recovery: false, library: 'empty' };
    case 'import': return { ...b, screen: 'import' };
    case 'setup': return { ...b, screen: 'setup', names: PARTIAL_NAMES, active: 'names', sony: 'partial' };
    case 'ready': return { ...b, screen: 'setup', names: FULL_NAMES, active: null, buzzSkipped: true, sony: 'partial' };
    case 'ready-buzzers': return { ...b, screen: 'setup', names: FULL_NAMES, active: 'buzzers', sony: 'partial' };
    case 'repair': return { ...b, screen: 'setup', gameId: 'moon', names: {}, active: 'teams' };
    case 'host': return { ...b, screen: 'host', names: FULL_NAMES, displayOpen: true, soundTested: true };
    case 'host-nodisplay': return { ...b, screen: 'host', names: FULL_NAMES, displayOpen: false, soundTested: true };
    case 'more': return { ...b, screen: 'host', names: FULL_NAMES, displayOpen: true, soundTested: true, moreOpen: true };
    case 'eight': return { ...b, screen: 'setup', gameId: 'systems', names: EIGHT_NAMES, active: 'names', sony: 'ready' };
    default: return state;
  }
}

const WORDS = { complete: 'Complete', optional: 'Optional', skipped: 'Skipped', attention: 'Needs attention', blocked: 'Blocked' };
const MARKS = { complete: '✓', optional: '○', skipped: '–', attention: '●', blocked: '!' };

export function model(s) {
  const game = gameById(s.gameId);
  const n = game.teams;
  const teamsOk = n >= 1 && n <= 8;
  const idx = Array.from({ length: Math.max(n, 0) }, (_, i) => i);
  const chosen = idx.map((i) => s.names[i]).filter(Boolean);
  const namesDone = teamsOk && chosen.length === n && new Set(chosen).size === chosen.length;
  const unnamed = idx.filter((i) => !s.names[i]).map((i) => `Team ${i + 1}`);
  const sonyReady = s.sony === 'ready';
  const responding = sonyReady ? n : s.sony === 'partial' ? Math.max(n - 1, 0) : 0;
  const ready = teamsOk && namesDone;
  const blocker = !teamsOk ? 'This game still needs teams before you can start.' : !namesDone ? (unnamed.length === 1 ? `${unnamed[0]} still needs a name.` : unnamed.length > 1 ? `${unnamed.length} teams still need names.` : 'Each team needs a different name.') : null;
  const active = !teamsOk ? 'teams' : s.active === 'teams' ? null : s.active;
  const rows = [
    { id: 'teams', label: 'Teams', status: teamsOk ? 'complete' : 'blocked', detail: teamsOk ? `${n} teams · set in the game` : 'No teams in this game', action: teamsOk ? null : 'Edit this game' },
    { id: 'names', label: 'Names', status: !teamsOk ? 'blocked' : namesDone ? 'complete' : 'attention', detail: !teamsOk ? 'Waiting on teams' : namesDone ? chosen.join(', ') : `${chosen.length} of ${n} chosen`, action: namesDone ? 'Change' : null },
    { id: 'buzzers', label: 'Buzzers', status: !teamsOk ? 'optional' : sonyReady ? 'complete' : s.buzzSkipped ? 'skipped' : 'optional', detail: !teamsOk ? 'Keyboard ready' : sonyReady ? `${n} controllers responding` : s.buzzSkipped ? 'Keyboard ready' : s.sony === 'partial' ? `${responding} of ${n} responding · keyboard ready` : 'Keyboard ready', action: !teamsOk ? null : sonyReady ? 'Check' : s.buzzSkipped ? 'Connect' : 'Skip' },
    { id: 'display', label: 'Display', status: s.displayOpen ? 'complete' : 'optional', detail: s.displayOpen ? 'Open' : 'Not open', action: s.displayOpen ? 'Focus display' : 'Open display' },
    { id: 'sound', label: 'Sound', status: (s.muted || s.soundTested) ? 'complete' : 'optional', detail: s.muted ? 'Muted' : s.soundTested ? 'Tested · on' : 'Not tested', action: s.soundTested ? 'Test again' : 'Test sound' },
  ].map((r) => ({ ...r, isActive: r.id === active, word: WORDS[r.status], mark: MARKS[r.status], isBlocked: r.status === 'blocked' }));
  const pending = [];
  if (!s.displayOpen) pending.push('Audience display is not open');
  if (!s.soundTested && !s.muted) pending.push('Sound has not been tested');
  if (!sonyReady && s.buzzSkipped) pending.push('Buzzers skipped');
  const teams = idx.map((i) => ({
    n: i + 1, label: `Team ${i + 1}`, accent: ACCENTS[i], name: s.names[i] || '', has: !!s.names[i],
    choices: BANK[i].map((name, k) => ({ name, color: SONY_COLORS[k], taken: chosen.includes(name) && s.names[i] !== name, picked: s.names[i] === name })),
  }));
  const controllers = idx.map((i) => ({ n: i + 1, team: s.names[i] || `Team ${i + 1}`, accent: ACCENTS[i], ok: i < responding }));
  return { game, n, teamsOk, namesDone, ready, blocker, active, rows, pending, statusLine: pending.join(' · '), teams, controllers, sonyReady, responding,
    heading: !teamsOk ? 'This game needs teams' : ready ? 'Ready' : 'Class setup',
    activeTeams: active === 'teams', activeNames: active === 'names', activeBuzzers: active === 'buzzers', activeDisplay: active === 'display', activeSound: active === 'sound' };
}
