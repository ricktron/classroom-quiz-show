# CQS MENUS D04 — B-Adapted pre-game workflow
**Version:** D04-R1 · v1.1 · 2026-09-28
**Status:** Candidate final reference — pending DevPM acceptance and repository storage.

## Identity
- Package: CQS MENUS D04 (Claude Design)
- Direction: **B-Adapted** — Console structure (D03-B) · Ledger tone (D03-A) · dark operational setup→game transition (idea from D03-C, realised with existing S17 darks)
- Final candidate after the D04-R1 fidelity repair pass

## Purpose
Preferred design evidence for the Classroom Quiz Show (CQS) teacher-facing **Home → Play → class setup → Ready → Start Game → in-game Host** workflow.

## Authority
- The CQS repository (canon, ADRs, contracts, implementation) remains authoritative.
- This package is design evidence / reference only. It does **not** authorize implementation and does **not** override current product contracts or ADRs.
- It becomes an implementation reference only after DevPM acceptance.

## Scope — reference for
Home hierarchy (recovery / no-recovery / empty) · Import entry (template → author externally → import → check → approve) · selected-Game context ("Game for this class · Change") · readiness rail (Teams · Names · Buzzers · Display · Sound) · single active setup step · Ready as a state of setup · Start Game transition · 0-team repair presentation (Edit this game) · immediate post-Start Host composition · More/Advanced presentation · status vocabulary (Complete / Optional / Skipped / Needs attention / Blocked; no "Current").

## Not authority for
Gameplay engine behaviour · persistence semantics · Sony hardware behaviour · Audience Display implementation · Windows/platform support claims · exact implementation mechanism · Session schema / state ownership.

## Files
- `CQS-MENUS-D04.dc.html` — package document: 12 frames at 1280×720, 1366×768 and 1093×542 (Windows 125 % simulation) renders, rationale, accessibility notes, DESIGN TENSION log, FOLLOW / ADAPT / REJECT ledger. **Open this file in a browser.**
- `D04-Console.dc.html` — the single clickable prototype. Runs live, or pin any state with the `frame` tweak (home, home-norecovery, home-empty, import, setup, ready, ready-buzzers, repair, host, host-nodisplay, more, eight).
- `d04-data.js` — sample science content + the readiness model mirrored from `src/session/classroomReadiness.ts` (design mirror, not production code).
- `support.js` — Design Component runtime required to render the two .dc.html files.
- `MANIFEST.md` — file list, purpose, render-requirement, SHA-256.

All files must stay in one folder; paths are relative. No network access is required.

## Provenance
1. D02 / COURT settled the information architecture (one readiness workspace, one active task, Ready as a state, Start Game).
2. **D03** explored three visual directions — A Ledger, B Console, C Daylight — on that architecture.
3. **D04** converged on B-Adapted.
4. **D04-R1** (this package) corrected fidelity/evidence issues: import safety copy aligned to parser behaviour; Backup/Diagnostics moved behind a Home "More" disclosure; Home no-recovery and empty-library variants added; T1 (Host tile height at 125 %) re-measured and closed as disproven; T2 reclassified as ADAPT / pending screen-reader qualification; "150 % unsupported" language removed.
D03 is historical exploration and is not part of, nor required by, this package.

## Measurements recorded in this package
Host board tile height (rendered): 1280×720 → 97–100 px · 1366×768 → 107–110 px · 1093×542 → 62–64 px.

## Open qualification items
- Physical Windows laptop observation at 1366×768 / 125 % (and any scaling not simulated here; **150 % was not qualified by this package**).
- Keyboard focus order and NVDA/JAWS behaviour of the rail (two focus stops per inactive row — T2).
- Real Sony Buzz receiver and controllers (all Sony states here are simulated).
- Physical projector as second screen (Open display → Focus display behaviour).
- Exact contents of the More tray, mapped to existing CQS functions.
- Rail behaviour below ~1000×520 (not designed).

## Attestation
The CQS repository (`ricktron/classroom-quiz-show`, branch `main`) was read only. It was not modified by this design work.
